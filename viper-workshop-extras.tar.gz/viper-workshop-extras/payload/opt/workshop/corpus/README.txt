Exploring the Digital Preservation Lifecycle
iPRES 2026, Copenhagen
A teaching corpus
================================================================================

--------------------------------------------------------------------------------
LAYOUT
--------------------------------------------------------------------------------

  01-identification/     extensions that lie, and a folder for batch runs
  02-validation/         well-formed, invalid, and broken, one of each
  03-characterization/   files carrying metadata worth extracting
  04-decisions/          two scenarios with no single right answer
  05-horizon/            policies and a notebook for building your own workflow
  shared/               where uploaded files from other participants appear

--------------------------------------------------------------------------------
THE THREE QUESTIONS THIS CORPUS IS BUILT AROUND
--------------------------------------------------------------------------------

1. WHAT IS THIS FILE?          identification, and why the extension is not evidence
2. IS IT WHAT IT CLAIMS?       validation, and why "valid" and "well-formed" differ
3. WHAT SHOULD I DO ABOUT IT?  policy, which is yours and not the tool's

Folders 01 to 03 map onto those questions in order. Folder 04 is where the third
question stops having a tidy answer.

--------------------------------------------------------------------------------
HOW TO RUN ANYTHING HERE
--------------------------------------------------------------------------------

Everything goes through one runner, which returns the same shape whatever tool
is underneath:

    dp-run fido 01-identification/mystery-file-1.dat
    dp-run jhove 02-validation/corrupted-pdf.pdf --opt module=PDF-hul
    dp-run verapdf 02-validation/pdfa-compliant.pdf --opt flavour=0
    dp-run --list

The same tools are also on the desktop as GUIs (DROID, JHOVE, veraPDF,
MediaInfo, Tika, the Arlington checker) and on the command line by their own
names. Press Up-arrow in a terminal: the shell history is pre-seeded with worked
preservation commands.

--------------------------------------------------------------------------------
THE JPEG 2000 FAMILY, AND FOUR FILES THAT CAME FROM UPSTREAM
--------------------------------------------------------------------------------

Four files here were not manufactured. They come from the jpylyzer test files,
CC-BY, and ATTRIBUTION.txt records each one with its upstream name and note.

They fill a gap nothing in this image can encode. High Throughput JPEG 2000 has
no encoder here, so htj2k-sample.jph is a real OpenHTJ2K-produced file rather
than something hand-faked to look like one.

The family is worth knowing, because "JPEG 2000" is four formats wearing one
name, and this image can tell them apart:

  x-fmt/392  JP2                       the boxed wrapper everyone means
  fmt/1794   JPEG 2000 Codestream      raw, no wrapper (.j2c, .j2k, .jpc)
  fmt/1964   JPH (JPEG 2000 part 15)   High Throughput, HTJ2K
  fmt/151    JPX (JPEG 2000 part 2)    the extended format

Confirm any of them locally rather than taking this on trust:

    grep -E '^(x-fmt/392|fmt/1794|fmt/1964|fmt/151),' \
      /opt/workshop/agent/reference/pronom-formats.csv

fmt/1964 arrived in PRONOM v125, which is the release this image carries. An
image built six months ago could not have named it.

module.exports = function (RED) {
    'use strict';
    const fs = require('fs');
    const path = require('path');

    // Hand-written, unlike the rest of the palette: this node has no tool behind it, so
    // there is no manifest to generate it from. It exists because Node-RED's own "file
    // in" node reads a file's *contents*, which is the opposite of what every OPF node
    // wants, and a participant reaching for the node called "file" otherwise gets a
    // silent no-op. See the defect note in the image README.
    function OpfFiles(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        node.path = config.path || '';
        node.recursive = config.recursive === undefined ? true : config.recursive;
        node.pattern = config.pattern || '';
        // Default 60, not unlimited. Wide enough for every shipped demo folder, narrow
        // enough that the corpus root (320 files) stops here instead of downstream.
        node.limit = config.limit === undefined || config.limit === '' ? 60 : Number(config.limit);

        function collect(target, recursive, out) {
            let entry;
            try {
                entry = fs.statSync(target);
            } catch (error) {
                return error.message;
            }
            if (entry.isFile()) { out.push(target); return null; }
            if (!entry.isDirectory()) { return target + ' is neither a file nor a folder'; }
            let names;
            try {
                names = fs.readdirSync(target);
            } catch (error) {
                return error.message;
            }
            names.sort().forEach(function (name) {
                if (name.charAt(0) === '.') { return; }   // skip dotfiles, not collection content
                const child = path.join(target, name);
                let childStat;
                try { childStat = fs.statSync(child); } catch (error) { return; }
                if (childStat.isDirectory()) {
                    if (recursive) { collect(child, recursive, out); }
                } else if (childStat.isFile()) {
                    out.push(child);
                }
            });
            return null;
        }

        node.on('input', function (msg, send, done) {
            send = send || function () { node.send.apply(node, arguments); };
            done = done || function (err) { if (err) { node.error(err, msg); } };

            // A path in the message wins over the configured one, so one flow can be
            // pointed at different folders without editing the node.
            let target = node.path;
            if (typeof msg.payload === 'string' && msg.payload !== '') {
                target = msg.payload;
            } else if (msg.payload && typeof msg.payload === 'object' && msg.payload.file) {
                target = msg.payload.file;
            }
            if (!target) {
                done('no path set: fill in Path, or send one as msg.payload');
                return;
            }

            const found = [];
            const failure = collect(target, node.recursive, found);
            if (failure) {
                node.status({ fill: 'red', shape: 'ring', text: 'cannot read' });
                done(failure);
                return;
            }

            let files = found;
            if (node.pattern) {
                let matcher;
                try {
                    matcher = new RegExp(node.pattern);
                } catch (error) {
                    done('bad filter pattern: ' + error.message);
                    return;
                }
                files = files.filter(function (file) { return matcher.test(file); });
            }

            if (files.length === 0) {
                node.status({ fill: 'yellow', shape: 'ring', text: 'no files' });
                done();
                return;
            }

            // Bound the batch. Every downstream OPF node spawns a process the moment a
            // message arrives, so the file count here is the fan-out width of the whole
            // flow. Pointed at the corpus root that is 320 files, and with two JVM
            // validators downstream it took a desktop down on 2026-09-15: memory and
            // swap exhausted, 86 processes OOM-killed, the instance still "up" and
            // unreachable.
            //
            // dp-run also gates expensive tools, so a large batch now queues rather
            // than stampedes. This limit is the earlier and kinder stop: it fails
            // visibly, on the node, before anything has run, rather than after a
            // participant has waited ten minutes.
            const total = files.length;
            const cap = Number(node.limit) > 0 ? Number(node.limit) : 0;
            if (cap && total > cap) {
                node.status({ fill: 'red', shape: 'ring',
                              text: total + ' files, limit ' + cap });
                done(total + ' files matched, which is over this node\u2019s limit of ' + cap +
                     '. Every file here becomes one process per downstream tool, so a batch ' +
                     'this wide can exhaust the desktop. Narrow the path, or raise Limit ' +
                     'deliberately if you know the flow can take it.');
                return;
            }

            node.status({ fill: 'green', shape: 'dot',
                          text: files.length + (files.length === 1 ? ' file' : ' files') });

            // One message per file, with msg.parts set so a join node downstream can
            // reassemble the batch without being told how many to expect.
            const groupId = RED.util.generateId();
            files.forEach(function (file, index) {
                const out = RED.util.cloneMessage(msg);
                out.payload = file;
                out.parts = {
                    id: groupId,
                    index: index,
                    count: files.length,
                    type: 'array'
                };
                send(out);
            });
            done();
        });
    }

    RED.nodes.registerType('opf-files', OpfFiles);
};

# Demo flow library

Five importable Node-RED flows, one per stage of the workshop. Generated from
`/opt/workshop/bin/dp-generate-flows` at image build time.

## Importing one

In the Node-RED editor: **Ctrl+I**, then *select a file to import*, and pick from
`/opt/workshop/flows/`. Each flow arrives as its own tab and runs immediately. Every one
starts with an **inject** node: press the button on its left.

Each flow's tab has a description. Open the **Explorer** panel to read it.

| File | Tab | What it shows |
|------|-----|---------------|
| `01-identify-folder.json` | 1. Identify a folder | The smallest useful flow. Also writes `identification.csv` to the Desktop |
| `02-compare-identifiers.json` | 2. Compare identifiers | One file through fido, DROID and Tika. The interesting cases are the disagreements |
| `03-policy-validation.json` | 3. Policy validation | **The centrepiece.** Route by PUID, validate, report |
| `04-characterise.json` | 4. Characterisation | Route by kind to MediaInfo, ExifTool or Tika |
| `05-ocr-to-pdfa.json` | 5. OCR to PDF/A | OCR a scan, normalise to PDF/A, then prove it with veraPDF |

## Flow 3 is the one to teach from

```
inject -> files -> fido -> switch on PUID -> [ six validators ] -> join -> summarise
                                                                          -> HTML -> Desktop
```

**The switch node is the policy.** Those rules *are* the preservation policy, drawn as
wires. There is no separate policy file to keep in step, and a participant can point at
the canvas and say what their institution does.

Adding a format is: add a rule to the switch, wire it to a validator. **Check the PUID
first** at `https://www.nationalarchives.gov.uk/PRONOM/<puid>`. `fmt/43` is JPEG File
Interchange Format 1.01, not JPEG 2000; JP2 is `x-fmt/392`.

The `else` output does not go straight to the report. It passes through a **no validator**
node that rewrites the status, because forwarding an identification envelope into a
validation report would claim we checked something we did not.

## Flow 5 is the strongest single demo

Three nodes make a complete preservation argument: OCRmyPDF claims to have produced
PDF/A, and then a separate, independent validator agrees.

```
OCRmyPDF  -> order-pdfa.pdf
veraPDF   -> status: valid, PDF/A-2b validation profile
```

## Where results go

| What | Where |
|------|-------|
| HTML report | `/config/Desktop/preservation-report.html` |
| Identification CSV | `/config/Desktop/identification.csv` |
| OCR output | `/config/Desktop/ocr-output/` |
| Per-message detail | the debug sidebar, and the container log |
| Per-file verdict | the status line under each node on the canvas |

## Node-RED specifics that cost debugging time

Recorded because each one failed silently rather than with an error.

**The `join` node must be in `auto` mode.** Auto reads `msg.parts`, which the `files`
node sets. `custom` mode ignores parts and waits for an explicit count, so with no count
it never completes: no output, no error, and a report that renders as an empty shell.

**The `template` node evaluates mustache against the whole `msg`, not `msg.payload`.**
So it is `{{payload.count}}`, not `{{count}}`. Get it wrong and every field renders as
nothing, with no warning.

**The `switch` node has no set-membership operator.** No `in`. Use an anchored regex
alternation, `^(fmt/18|fmt/19)$`, and anchor it: unanchored, `fmt/1` matches `fmt/199`.

**Every `join` needs an explicit timeout.** A join waiting on a message that never
arrives waits for ever. Each of these sets 120 seconds.

**Regenerating the nodes needs a Node-RED restart.** Node-RED loads node code once at
startup. `dp-generate-nodes` writing new files changes nothing until
`s6-svc -r /run/service/svc-nodered`.

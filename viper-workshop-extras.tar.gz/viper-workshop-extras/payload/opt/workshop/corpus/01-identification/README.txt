01 IDENTIFICATION
What is this file, and why is the extension not evidence?
================================================================================

Four of the seven files here have a filename that disagrees with their contents,
and a fifth has one that is almost right, which is worse. None of it is a trick:
this is the ordinary condition of material arriving from a donor, a hard drive,
or a decade-old migration.

--------------------------------------------------------------------------------
WHAT EACH FILE ACTUALLY IS
--------------------------------------------------------------------------------

Verified with fido on this image, PRONOM v125:

  FILE                     SAYS        ACTUALLY IS
  mystery-file-1.dat       .dat        fmt/43     JPEG File Interchange Format
  mystery-file-2.bin       .bin        fmt/276    Acrobat PDF 1.7
  mystery-file-3           nothing     fmt/11     Portable Network Graphics
  document.docx            .docx       fmt/412    Microsoft Word for Windows
  archive.zip              .zip        x-fmt/263  ZIP Format
  webpage.html             .html       fmt/471    Hypertext Markup Language
  mystery-file-4.jp2       .jp2        fmt/1794   JPEG 2000 Codestream

The last three tell the truth. Two of them are worth a second look anyway, for
reasons below. mystery-file-4 is the subtlest case in the corpus and has its own
exercise at the end.

--------------------------------------------------------------------------------
EXERCISE 1: ASK THE FILE, NOT THE NAME
--------------------------------------------------------------------------------

    dp-run fido mystery-file-1.dat
    dp-run fido mystery-file-3

The envelope you get back carries the PUID, the format name, and a sha256. Note
that mystery-file-3 has no extension at all and is identified anyway, because
identification reads the bytes at the start of the file.

Then confirm the PUID against the local reference rather than trusting anyone,
including this README:

    grep '^fmt/43,' /opt/workshop/agent/reference/pronom-formats.csv

--------------------------------------------------------------------------------
EXERCISE 2: THREE TOOLS, ONE FILE
--------------------------------------------------------------------------------

    dp-run fido mystery-file-2.bin
    dp-run siegfried mystery-file-2.bin
    dp-run droid mystery-file-2.bin
    dp-run tika-detect mystery-file-2.bin

The first three read PRONOM signatures. Tika does content-based media type
detection instead, so it answers a different question and will not give you a
PUID at all.

Two things to notice. Siegfried reports its BASIS, the actual byte match that
justified the answer, which no other tool here does. And DROID takes about ten
seconds against fido's third of a second, almost all of it JVM startup, for the
same answer.

Before concluding any of them is wrong, run:

    dp-signatures

They do not all read the same PRONOM release, and "the tools disagree" is
sometimes "the tools were given different evidence".

--------------------------------------------------------------------------------
EXERCISE 3: THE CONTAINER FORMATS
--------------------------------------------------------------------------------

document.docx and archive.zip are both, underneath, zip files.

    dp-run fido document.docx
    dp-run fido archive.zip

One comes back as Word, the other as ZIP. The difference is the CONTAINER
SIGNATURE: a second signature file that identifies a format by what is inside
the zip rather than by its first few bytes.

This is where the signature versions in dp-signatures start to matter. fido
freezes its container signature deliberately, so on container formats it can be
current on the format list and years behind on containers at the same time.

Look inside, then decide whether the tools are telling you enough:

    unzip -l document.docx
    unzip -l archive.zip

archive.zip holds a PDF, a JPEG, an HTML file and a CSV. Nothing you ran told
you that. A folder of zips is a folder of unanswered questions.

--------------------------------------------------------------------------------
EXERCISE 4: BATCH, AND THE FIRST THING THAT BITES
--------------------------------------------------------------------------------

batch-folder/ holds 24 files: JPEGs, PNGs, PDFs, text, a CSV, and two more
extension lies (not-really-a-doc.docx is a JPEG, spreadsheet.xlsx is a PDF).

On the command line:

    fido -r batch-folder/
    dp-run fido batch-folder/image-01.jpg

In a flow, open tab 1 and point the files node here. NOTE THE LIMIT on that
node, default 60. Every file becomes one process per downstream tool, so a
folder times a fan-out is a process count, and this desktop has a hard 4 GiB
ceiling. 24 files is comfortable. The full JHOVE corpus at /config/test-corpus
is 320 and is not.

--------------------------------------------------------------------------------
EXERCISE 5: THE EXTENSION THAT IS ALMOST RIGHT
--------------------------------------------------------------------------------

    dp-run fido mystery-file-4.jp2

It comes back fmt/1794, "JPEG 2000 Codestream". Not x-fmt/392, which is JP2.

The extension is .jp2 and the file IS JPEG 2000. It is just not the JP2 format.
JP2 is a boxed wrapper around a codestream; this file is the bare codestream
with no wrapper at all. So the extension is not a lie exactly, it is a category
error, and those are harder to spot and more common than outright lies.

"JPEG 2000" is four formats wearing one name:

    grep -E '^(x-fmt/392|fmt/1794|fmt/1964|fmt/151),' \
      /opt/workshop/agent/reference/pronom-formats.csv

Now watch what that costs you downstream. Ask a validator to check it as JP2,
which is what the extension implies, and then as what it actually is:

    dp-run jpylyzer mystery-file-4.jp2 --opt format=jp2
    dp-run jpylyzer mystery-file-4.jp2 --opt format=j2c

Invalid, then valid. The same bytes. A perfectly good file, condemned by being
checked against the wrong expectation, and the wrong expectation came from the
filename.

This file is byte-for-byte identical to balloon.j2c in the jp2kMagic repository,
which is the same codestream under an honest extension. Identical sha256, one
verdict each, decided entirely by what someone typed after the dot.

--------------------------------------------------------------------------------
WHAT TO TAKE AWAY
--------------------------------------------------------------------------------

The extension is a claim made by whoever last renamed the file. Identification
is evidence about the bytes. They are different kinds of statement, and only one
of them survives contact with a donor's hard drive.

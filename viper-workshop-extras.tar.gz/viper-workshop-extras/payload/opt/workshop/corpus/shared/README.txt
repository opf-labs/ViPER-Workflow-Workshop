SHARED
Files from other participants
================================================================================

This folder is where files uploaded by other people in the room appear. It is
mounted READ-ONLY, so you can analyse anything here but not change it. Writing
will fail, and that is the mount, not a permissions mistake you can fix.

Put your own output on the Desktop or in /config/scratchpad instead.

--------------------------------------------------------------------------------
HOW FILES GET HERE
--------------------------------------------------------------------------------

The facilitator will give you the upload address at the start of the session,
along with the shared password. It is deliberately not printed here, because a
URL baked into an image months in advance is a URL that has moved by the time
anyone reads it.

Ask, or look at the slide.

--------------------------------------------------------------------------------
WHY THIS IS THE MOST INTERESTING FOLDER IN THE CORPUS
--------------------------------------------------------------------------------

Everything else you have run today was chosen by somebody who knew what the
answer would be. The files here were not.

That is the actual job. Material arrives, nobody tells you what it is, and the
tools are the only thing standing between you and a guess.

So when something appears here:

    dp-run fido "/config/shared/whatever-it-is"
    dp-signatures

Then route it, validate it with the right tool, and see whether your policy
copes. If a colleague's file breaks your workflow, that is worth more to you
than another file that passes.

--------------------------------------------------------------------------------
A NOTE ON WHAT YOU UPLOAD
--------------------------------------------------------------------------------

Everyone in the room can read what you put here, and the assistant can read it
too. Do not upload anything confidential, anything under embargo, or anything
carrying personal data you would not read aloud.

Folder 03 is a good reminder of why: the photograph in there has GPS
coordinates, a camera serial, and a timestamp, none of which are visible from
the filename. Your files may too.

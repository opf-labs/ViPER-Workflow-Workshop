# /opt/workshop

Everything added to ViPER v2.0.0-alpha for the iPRES 2026 Digital Preservation
Lifecycle workshop. Nothing outside this directory is workshop-specific, apart from
symlinks pointing back into it and the packages installed by apt, npm and pip.

```text
/opt/workshop/
├── flows/         5 importable demo flows, one JSON each, plus a README
├── notebooks/     6 JupyterLab notebooks, masters. 01 to 05 mirror the five flows
├── agent/         AGENTS.md, opencode.json, and reference/ for the assistant
├── tools/         one manifest per tool. The single source of truth for invocation
├── bin/           dp-run, the dp-generate-* builders, and the desktop launchers
├── node-red/      settings.js, the flows.json seed, and the OPF palette in nodes/
├── desktop/       .desktop launchers, symlinked into the ViPER desktop staging dir
├── icons/         launcher icons, symlinked into /usr/share/icons
└── s6/            service definitions, symlinked into /etc/s6-overlay/s6-rc.d
```

A fuller map, including the runtime `/config` side, is `workshop-filesystem.md` in the
project repository.

## The parts you are most likely to want

| You want | Look at |
|----------|---------|
| The demo flows | `flows/*.json`, or the live canvas at `/config/.node-red/flows.json` |
| The notebooks | `notebooks/*.ipynb`, working copies in `/config/notebooks` |
| What the assistant is told | `agent/AGENTS.md` |
| What the assistant may run | `agent/opencode.json` |
| The PUID authority | `agent/reference/pronom-formats.csv`, 2,571 formats, greppable |
| How a tool is invoked | `tools/<tool>.yml`. Change it here, `dp-run` reads it live |

## Everything runs through dp-run

```bash
dp-run <tool> <file> [--opt name=value ...]
dp-run --list
```

One normalised JSON envelope whatever the tool emits natively, so the Node-RED palette,
a notebook and a shell pipeline all see the same shape. `dp-signatures` reports which
PRONOM release each identification tool is actually reading.

## Where the symlinks point

| Canonical location | Target here |
|--------------------|-------------|
| `/usr/local/bin/dp-run` | `bin/dp-run` |
| `/usr/local/bin/viper-workflows` | `bin/viper-workflows` |
| `/usr/share/applications/viper-workflows.desktop` | `desktop/viper-workflows.desktop` |
| `/usr/share/icons/node-red.png` | `icons/node-red.png` |
| `/etc/s6-overlay/s6-rc.d/svc-nodered` | `s6/svc-nodered` |

The s6 **bundle membership** file, `/etc/s6-overlay/s6-rc.d/user/contents.d/svc-nodered`,
is an empty marker that has to be a real file in the bundle directory. It is not
symlinked.

## What is not here

`/config` is a runtime volume and must leave the build empty, so nothing workshop-owned
lives there in the image. Instead the masters here are seeded into `/config` on demand,
and **only when the target is absent**, so participant edits survive a restart:

| Master here | Working copy | Seeded |
|-------------|--------------|--------|
| `node-red/flows.json` | `/config/.node-red/flows.json` | first start only |
| `node-red/settings.js` | `/config/.node-red/settings.js` | first start only |
| `notebooks/*.ipynb` | `/config/notebooks/` | first `viper-notebooks` run |
| `agent/opencode.json` | `/config/.config/opencode/opencode.json` | first `viper-assistant` run |

The assistant also gets `/config/scratchpad` as its working directory, created by the
launcher and linked onto the Desktop. It is the one path its permissions let it write to
without asking.

Every row here is seeded **only when the target is absent**, including the two Node-RED
files. `svc-nodered/run` guards the copy with `! -f`, so a restart will not refresh a
working copy and a participant who has broken their canvas does not get the demo flows
back by restarting. To reset one, delete it and restart the service:

```bash
rm /config/.node-red/flows.json && s6-svc -r /run/service/svc-nodered
```

That also applies to a new image: an updated seed does **not** reach a `/config` volume
that already carries the old one, which is worth knowing when testing a new revision
against a pooled instance.

`node-red/nodes/` is the exception: it is read directly via `nodesDir` in `settings.js`
and never copied. Node-RED loads node code once at startup, so changing a node needs
`s6-svc -r /run/service/svc-nodered`.

02 VALIDATION
Is this file what it claims to be, and is it even intact?
================================================================================

Identification told you what a file is. Validation asks whether it is a good
example of that thing. These are different questions and they have different
answers, which is the whole point of this folder.

--------------------------------------------------------------------------------
THE VOCABULARY, AND WHY FOUR WORDS NOT TWO
--------------------------------------------------------------------------------

  valid            well-formed AND obeys the format's semantic rules
  invalid          well-formed, but breaks a rule. Readable, non-conforming
  not_well_formed  structurally broken. A different and worse problem
  no_validator     nothing here can check this format. Not a pass

"Corrupt" is not in that list because it is not precise enough to act on. A file
that is invalid may be perfectly usable. A file that is not well formed may not
open at all.

--------------------------------------------------------------------------------
WHAT EACH FILE IS, VERIFIED
--------------------------------------------------------------------------------

Every verdict below was produced by running the tool named, on this image:

  valid-pdf.pdf          fmt/276   JHOVE PDF-hul    valid
  corrupted-pdf.pdf      none      JHOVE PDF-hul    not_well_formed
                         "No PDF trailer (at byte 2087)"
                         Unidentified on purpose. See the note below the table.
  pdfa-compliant.pdf     fmt/477   veraPDF          valid   (PDF/A-2b)
  pdfa-noncompliant.pdf  fmt/477   veraPDF          invalid
  valid-tiff.tif         fmt/353   JHOVE TIFF-hul   valid
  truncated-tiff.tif     fmt/353   JHOVE TIFF-hul   not_well_formed
                         "Premature EOF (at byte 2880008)"
  valid-jpeg.jpg         fmt/43    JHOVE JPEG-hul   valid
  valid-jp2.jp2          x-fmt/392 jpylyzer         valid
  invalid-jp2.jp2        x-fmt/392 jpylyzer         invalid
                         csizIsValid False, lsizConsistentWithCsiz False
  htj2k-sample.jph       fmt/1964  jpylyzer         valid
  htj2k-wrong-bpc.jph    fmt/1964  jpylyzer         invalid
                         bPCDepthConsistentWithSIZ False
  raw-codestream.j2c     fmt/1794  jpylyzer         valid
  odf-valid.odt          fmt/290   odf-validator    valid
  odf-bad-mimetype-order.odt
                         fmt/136   odf-validator    invalid
  odf-bad-mimetype-value.odt
                         fmt/136   odf-validator    invalid
  odf-no-manifest.odt    fmt/290   odf-validator    invalid
  odf-bad-content-xml.ods
                         fmt/137   odf-validator    invalid
  odf-extended-text.odt  fmt/290   odf-validator    invalid, valid extended
  odf-extended-calc.ods  fmt/294   odf-validator    invalid, valid extended
  odf-extended-draw.odg  fmt/296   odf-validator    invalid, valid extended

corrupted-pdf.pdf has no PUID and that is the honest answer, not a gap. Run it:

    dp-run fido corrupted-pdf.pdf

    status: multiple_matches, puid: null

    "fido matched on extension, not on a byte signature, so the format is a guess
     from the filename. 32 formats share this extension; the PUID has been
     discarded rather than passed on."

The file is damaged badly enough that no byte signature matches, so fido falls back to
the extension and lists all 32 formats that use .pdf, starting with fmt/95. Taking that
first row as the identification would mean reporting "Acrobat PDF/A" about a file whose
only qualification is ending in .pdf. The runner discards it instead.

The consequence shows up in flow 3: this file reaches no validator, because nothing
identified it and the routing table routes on PUID. JHOVE will still diagnose it if you
name the module yourself, which is Exercise 1. **Both behaviours are correct.** A
validator needs to be told what to expect, and a broken file may not be able to tell you.

--------------------------------------------------------------------------------
EXERCISE 1: WELL-FORMED VERSUS VALID
--------------------------------------------------------------------------------

    dp-run jhove valid-pdf.pdf      --opt module=PDF-hul
    dp-run jhove corrupted-pdf.pdf  --opt module=PDF-hul

The second is not_well_formed, and JHOVE tells you exactly where it gave up:
no PDF trailer at byte 2087. That precision is the reason to run a validator
rather than trying to open the file and seeing what happens.

--------------------------------------------------------------------------------
EXERCISE 2: THE MOST IMPORTANT PAIR IN THIS CORPUS
--------------------------------------------------------------------------------

    dp-run fido    pdfa-compliant.pdf
    dp-run fido    pdfa-noncompliant.pdf

Both come back as fmt/477, "Acrobat PDF/A". Identification agrees they are both
PDF/A. Now:

    dp-run verapdf pdfa-compliant.pdf    --opt flavour=0
    dp-run verapdf pdfa-noncompliant.pdf --opt flavour=0

One is valid. One is not. Same PUID, opposite verdicts.

The non-compliant file was produced by converting a real document to PDF/A with
ocrmypdf, which reported "Output file is a PDF/A-2b (as expected)". It fails on
exactly one rule out of 144:

  clause 6.2.4.2  The profile that forms the stream of an ICCBased colour space
                  shall conform to ICC.1:1998-09, ICC.1:2001-12, ICC.1:2003-09
                  or ISO 15076-1

An ICC colour profile inherited from the source document. See it yourself:

    verapdf --format text -f 2b pdfa-noncompliant.pdf

Three lessons, and they are the ones this workshop is actually about:

  1. A CONVERTER REPORTING SUCCESS IS NOT VALIDATION. The tool said "as
     expected" about a file that fails.
  2. IDENTIFICATION IS NOT VALIDATION. fmt/477 describes the claim the file
     makes about itself, not whether the claim is true.
  3. CONVERSION INHERITS THE SOURCE'S PROBLEMS. You cannot normalise your way
     out of a bad colour profile.

--------------------------------------------------------------------------------
EXERCISE 3: THE RIGHT VALIDATOR FOR THE FORMAT
--------------------------------------------------------------------------------

    dp-run jhove    valid-jp2.jp2 --opt module=JPEG2000-hul
    dp-run jpylyzer valid-jp2.jp2 --opt format=jp2

Both will look at a JP2. jpylyzer was written for JPEG 2000 specifically and
reports far more about the codestream. Then:

    dp-run jpylyzer invalid-jp2.jp2 --opt format=jp2

That file still identifies as x-fmt/392, because its JP2 signature box is
intact. Only a validator that reads the codestream notices that the image size
markers are inconsistent. The damage is deliberately inside the codestream for
exactly this reason.

--------------------------------------------------------------------------------
EXERCISE 4: FOUR FORMATS CALLED JPEG 2000
--------------------------------------------------------------------------------

jpylyzer needs to be told which member of the family it is looking at, and it
will do as it is told:

    dp-run jpylyzer valid-jp2.jp2         --opt format=jp2
    dp-run jpylyzer raw-codestream.j2c    --opt format=j2c
    dp-run jpylyzer htj2k-sample.jph      --opt format=jph

Three formats, three PUIDs, three valid verdicts:

    x-fmt/392  JP2                      the boxed wrapper
    fmt/1794   JPEG 2000 Codestream     raw, unwrapped
    fmt/1964   JPH (JPEG 2000 part 15)  High Throughput

Then the broken one:

    dp-run jpylyzer htj2k-wrong-bpc.jph --opt format=jph

    bPCDepthConsistentWithSIZ  False

It still identifies as fmt/1964, because the JPH wrapper is intact. The bits per
component declared in the image header disagree with the codestream's own SIZ
marker, and only a validator that reads both notices. Identification and
validation, one more time, on a format that did not have a PUID until PRONOM
v125.

htj2k-sample.jph is a real OpenHTJ2K-encoded file from the jpylyzer test suite,
not something manufactured here. Nothing in this image can encode HTJ2K, and a
hand-built file carrying the JPH brand over a classic codestream would identify
as fmt/1964 while not being HTJ2K at all. See ATTRIBUTION.txt.

--------------------------------------------------------------------------------
EXERCISE 5: ODF, WHERE BREAKING A FILE CHANGES WHAT IT IS
--------------------------------------------------------------------------------

An ODF document is a zip with rules about how the zip is built. The first entry
must be a file called mimetype, it must be stored uncompressed, and it must hold
the right media type. Those rules exist so a reader can identify the document
from its first few bytes without unpacking it.

Start with the good one:

    dp-run odf-validator odf-valid.odt

Valid. Read the checks in the output rather than just the verdict:

    DOC-2  INFO     OpenDocument version 1.3 detected
    DOC-3  INFO     OpenDocument MIMETYPE ...opendocument.text detected
    PKG-7  WARNING  An OpenDocument Package SHOULD contain a preview image

**That file is valid and carries a warning.** SHOULD is not MUST, so a missing
thumbnail is worth telling you about and is not a failure. If your policy treats
every warning as a rejection, you have just rejected a good document.

Now the broken ones, which fail in three different ways:

    dp-run odf-validator odf-bad-mimetype-order.odt   # mimetype not first, deflated
    dp-run odf-validator odf-bad-mimetype-value.odt   # mimetype says spreadsheet
    dp-run odf-validator odf-no-manifest.odt          # META-INF removed
    dp-run odf-validator odf-bad-content-xml.ods      # content.xml breaks the schema

The first three are PACKAGE errors: the zip is wrong. The last is a DOCUMENT
error, XML-4, where the package is fine and the XML inside does not satisfy the
schema. ODF validation has those two levels and the distinction matters when you
are deciding whether a file can be repaired.

Then the part worth stopping on. Identify all four:

    dp-run fido odf-valid.odt
    dp-run fido odf-bad-mimetype-order.odt

    odf-valid.odt                fmt/290   OpenDocument Text 1.1
    odf-bad-mimetype-order.odt   fmt/136   OpenDocument Text 1.0

**Breaking the packaging changed the identification.** Nothing about the
document's content or version changed; the only edit was where mimetype sits in
the zip. ODF is recognised by a container signature that expects mimetype first
and uncompressed, so when that is not true the tools fall back to a different
match.

This is identification and validation touching each other in one file, and it
has a practical consequence: if your routing table lists only the 1.1 PUIDs,
every damaged ODF you own is routed away from the validator that would have told
you what was wrong with it. The policy in 05-horizon lists both for that reason.

--------------------------------------------------------------------------------
EXERCISE 6: STRICT AND EXTENDED, AND WHY YOUR OWN FILES FAIL
--------------------------------------------------------------------------------

The three odf-extended-* files were made in LibreOffice and saved with no special
settings, the way anyone would. All three are invalid:

    dp-run odf-validator odf-extended-text.odt
    dp-run odf-validator odf-extended-calc.ods
    dp-run odf-validator odf-extended-draw.odg

One error each, or two, and always the same code:

    DOC-8  ERROR  content.xml uses the following extended namespace prefixes loext

Now ask the same question in extended mode:

    dp-run odf-validator odf-extended-text.odt --opt extended=true

Valid. Same bytes, same tool, opposite verdict. The three files use calcext,
officeooo and loext between them, all of them vendor namespaces that ODF permits
but that pure ODF does not use.

These are two different questions, and both are legitimate:

    strict    is this pure ODF?
    extended  is this ODF plus vendor extensions the standard allows?

Almost everything LibreOffice writes fails the first and passes the second. That is
not a broken document and it is not a broken validator. It is a conformance level,
and choosing one is a policy decision that belongs to you. If your policy is strict,
you have just rejected the output of the most common ODF editor in existence.

Extended mode does not forgive real faults. Check:

    dp-run odf-validator odf-bad-content-xml.ods --opt extended=true

Still invalid. XML-4 is a schema violation, not a namespace, and no conformance
level makes it go away.

--------------------------------------------------------------------------------
EXERCISE 7: THREE TOOLS, THREE ANSWERS, ONE SPREADSHEET
--------------------------------------------------------------------------------

    dp-run fido      odf-extended-calc.ods
    dp-run siegfried odf-extended-calc.ods
    dp-run droid     odf-extended-calc.ods

    fido       fmt/294    OpenDocument Spreadsheet 1.1
    siegfried  fmt/1755   OpenDocument Spreadsheet 1.3
    droid      fmt/1755   OpenDocument Spreadsheet 1.3

The file is ODF 1.3. The validator says so itself:

    DOC-2  INFO  package OpenDocument version 1.3 detected

So fido is wrong, and it is wrong for a reason you can check rather than guess:

    dp-signatures

fido freezes its container signature, and ODF version is decided by a container
signature. fido is current on the format list and years behind on containers, so it
matches the newest ODF it knows, which is 1.1.

The consequence is not academic. A routing table listing only the 1.1 PUIDs works
perfectly behind fido and silently drops every real LibreOffice document to
no_validator behind siegfried or DROID. The policy in 05-horizon lists all four
version families for that reason.

--------------------------------------------------------------------------------
EXERCISE 8: TWO OPINIONS ON ONE PDF
--------------------------------------------------------------------------------

    dp-run verapdf   valid-pdf.pdf --opt flavour=0
    dp-run arlington valid-pdf.pdf

veraPDF asks "does this meet the PDF/A profile it claims?". Arlington asks "does
this obey the PDF specification for its own version?". They disagree routinely
and neither is at fault, because they are not answering the same question.

Arlington is a veraPDF development build and the Arlington model is still
maturing, so treat a failed rule there as evidence to investigate rather than a
verdict that a file is broken.

--------------------------------------------------------------------------------
WHAT TO TAKE AWAY
--------------------------------------------------------------------------------

no_validator is not a pass. If nothing in your toolchain can check a format,
you do not know the file is good, you know you did not look. Say so in the
record rather than letting silence read as approval.

# Module 5: Build your own workflow

Everything in modules 1 to 4 ran one tool at a time and asked you to read the
answer. This module is about stringing tools together, and about the fact that
the interesting decisions are the ones the tools cannot make.

## Two ways in, and they are the same thing underneath

**The canvas.** Open **ViPER Workflows** from the desktop. Six tabs: a starter
and five worked examples. Tab 3, *Policy validation*, is the one to teach from,
because it is the whole lifecycle in one flow: identify, route on PUID, validate
with the right tool, collect, and write a report.

**The notebook.** `workflow-builder.ipynb` in this folder, opened with **ViPER
Notebooks**. Same exercises, same corpus, same results.

Both call `dp-run`, so a workflow you build in one is the same workflow in the
other. Pick whichever you think better, and ignore anyone who tells you that
choice is a technical one.

## The policies

`policies/` holds three profiles that differ **only in their actions**:

| | invalid | not_well_formed | no_validator |
|---|---|---|---|
| `default.yaml` | flag_for_review | quarantine | accept_with_note |
| `strict.yaml` | reject | reject | quarantine |
| `permissive.yaml` | accept_with_note | accept_with_note | accept_with_note |

The routing table, which validator runs for which PUID, is identical in all
three. That is the point worth spending a minute on: **institutions almost never
disagree about what the tools found. They disagree about what to do about it.**

Section 4 of the notebook swaps the profile and re-decides the same evidence.
Run it, then argue.

`strict.yaml` adds one condition beyond the verdict: a file claiming PDF/A must
actually pass veraPDF. Folder 02 contains the file that fails exactly that test
while identifying as PDF/A, which is why the condition exists.

## Exercises, roughly in order of difficulty

1. **Run tab 3** against `02-validation/` and read the report on your Desktop.
2. **Change the policy.** Edit the switch in tab 3, or the profile in the
   notebook, and re-run. Same evidence, different decisions.
3. **Add a tool.** Drag an `Arlington` node in beside `veraPDF` in tab 3. Two
   opinions on one PDF, answering two different questions.
4. **Build a migration with a gate.** Convert a PDF to PDF/A, then validate the
   output, and only record success if the validator agrees. The converter will
   tell you it worked either way.
5. **Write a report you would sign.** Tool, tool version, sha256, status, and
   the errors. Every `dp-run` envelope already carries all of it.

## Two things that will bite

**Fan-out.** Every OPF node starts a process the moment a message arrives, so
files times tools is a process count. This desktop has a hard 4 GiB ceiling and
an unbounded flow over a large folder will exhaust it. The `files` node has a
limit, default 60, and every flow has a rate limiter. They are there because a
flow without them took a desktop down during preparation. Identify first and
validate only what needs it.

**The assistant is a colleague, not an oracle.** Press **ViPER Assistant**. It
can run `dp-run`, grep the PUID reference, and emit flow JSON. Ask it *why* as
well as *what*, and check its PUIDs: the reference CSV is right there and a
`grep` settles any argument in a fraction of a second.

## Where things are

```
/config/Desktop/workshop-corpus/     this corpus
/config/test-corpus/                 the JHOVE test corpora, 320 files
/opt/workshop/tools/*.yml            one manifest per tool, the source of truth
/opt/workshop/flows/                 the five demo flows, importable
/opt/workshop/agent/reference/       pronom-formats.csv, 2,571 formats, greppable
dp-run --list                        what is actually installed
dp-signatures                        which PRONOM release each tool reads
```

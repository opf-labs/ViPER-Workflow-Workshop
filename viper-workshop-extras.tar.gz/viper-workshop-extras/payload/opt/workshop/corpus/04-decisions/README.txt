04 DECISIONS
The part where the tools stop helping
================================================================================

Everything so far had a correct answer. A PUID is right or wrong. A file is
well-formed or it is not. You can check.

This folder has no correct answers, and that is the point. The tools produce
information. Your institution makes the decision. Anyone who tells you a
validator decided something for them has skipped a step they are accountable
for.

--------------------------------------------------------------------------------
THE DEFAULT MAPPING, AND WHY IT IS ONLY A DEFAULT
--------------------------------------------------------------------------------

  valid             -> proceed_to_ingest
  invalid           -> flag_for_review
  not_well_formed   -> quarantine
  no_validator      -> accept_with_note

That is a reasonable starting position. It is not a truth. Whether an invalid
file gets reviewed or rejected depends on what it is worth, what your policy
says, and what remediation you can actually afford. A unique primary source you
cannot replace is treated differently from one of forty copies.

--------------------------------------------------------------------------------
SCENARIO ONE: THE DONATION
--------------------------------------------------------------------------------

scenario-donation/ is a small stand-in for a much larger accession.

  photo-1..6.jpg          the bulk of it, ordinary JPEGs
  deed-of-gift.pdf        the paperwork, and the only irreplaceable item
  damaged-scan.pdf        not_well_formed, and the only copy
  notes.txt              a transcription
  uncompressed-master.tif a large TIFF

You have received this and a further 500 files from a donor. Run the corpus,
then answer as a group:

  1. damaged-scan.pdf will not validate and there is no second copy. Do you
     quarantine it, keep it as-is with a note, attempt repair, or go back to the
     donor? What does your answer cost, and who signs it off?
  2. deed-of-gift.pdf is administratively critical and technically unremarkable.
     Does it get the same treatment as the photographs, or different?
  3. uncompressed-master.tif is large and valid. Do you keep it, or derive a
     compressed access copy and keep both? Which one is the preservation master?
  4. You did not write these filenames. Do they mean anything, and would you
     rename before ingest? What do you lose by renaming?

    dp-run fido scenario-donation/damaged-scan.pdf
    dp-run jhove scenario-donation/damaged-scan.pdf --opt module=PDF-hul

--------------------------------------------------------------------------------
SCENARIO TWO: THE MIGRATION
--------------------------------------------------------------------------------

scenario-migration/ is a set of candidates for format migration.

  legacy-scan.jp2         valid JP2
  report-for-pdfa.pdf     a plain PDF, a candidate for PDF/A
  tiff-master.tif         valid TIFF
  lossy-audio.mp3         already lossy

Try one migration for real, and then check it rather than trusting it:

    dp-run ocrmypdf scenario-migration/report-for-pdfa.pdf \
      --opt output=/config/Desktop/migrated.pdf --opt output_type=pdfa
    dp-run verapdf /config/Desktop/migrated.pdf --opt flavour=0

Then argue about:

  1. The conversion reported success. Did you verify it, or believe it? Folder
     02 has a file where those two answers differ.
  2. lossy-audio.mp3 is already lossy. Migrating it to a lossless format makes
     a bigger file and recovers nothing. Is there any reason to do it?
  3. If you migrate, do you keep the original? For how long? Migration is a
     decision to hold two things forever, not one thing in a better format.
  4. What do you record so that somebody in ten years knows what happened, what
     tool did it, and what version that tool was? Every dp-run envelope carries
     the tool, its version and a sha256 for exactly this reason.

--------------------------------------------------------------------------------
WHAT TO TAKE AWAY
--------------------------------------------------------------------------------

A preservation result that cannot say what produced it is not much use later.
The tools give you that provenance for free. The judgement is the part nobody
can automate for you, and the part you are actually paid for.

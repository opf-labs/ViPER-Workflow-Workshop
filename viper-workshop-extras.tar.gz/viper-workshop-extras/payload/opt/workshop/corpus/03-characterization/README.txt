03 CHARACTERIZATION
What else can this file tell me about itself?
================================================================================

Identification says what a file is. Validation says whether it is a good one.
Characterisation asks what is inside it: dimensions, codecs, durations, colour
spaces, authorship, timestamps, the camera that took it.

Some of that you want in your catalogue. Some of it you may need to remove
before publishing. Both cases start with knowing it is there.

--------------------------------------------------------------------------------
WHAT IS HERE
--------------------------------------------------------------------------------

  photo-with-exif.jpg          fmt/43     EXIF: camera, artist, GPS, timestamps
  document-with-metadata.odt   fmt/290    ODF with real dc: and meta: fields
  video-sample.mp4             fmt/199    H.264 video plus AAC audio, 6 seconds
  audio-sample.mp3             fmt/134    MP3 with ID3v2 tags
  stripped-image.png           fmt/11     the same image with metadata removed
  jp2-with-metadata.jp2        x-fmt/392  JP2 carrying XMP

--------------------------------------------------------------------------------
EXERCISE 1: THE SAME PICTURE, TWICE
--------------------------------------------------------------------------------

    dp-run exiftool photo-with-exif.jpg
    dp-run exiftool stripped-image.png

Counted on this image: 41 tags against 20. The second file is the same picture
with the metadata stripped, so the difference is what metadata was worth.

Look at what the first one carries:

    exiftool -Make -Model -Artist -Copyright -GPSLatitude -GPSLongitude \
             -DateTimeOriginal photo-with-exif.jpg

There are GPS coordinates in there. They point at Copenhagen. Whether that is
an asset or a disclosure problem depends entirely on what the material is and
who is going to see it, which is a policy question and not a tool question.

--------------------------------------------------------------------------------
EXERCISE 2: THE AUDIOVISUAL PAIR
--------------------------------------------------------------------------------

    dp-run mediainfo video-sample.mp4
    dp-run mediainfo audio-sample.mp3

MediaInfo gives you container, codecs, bit depth, frame rate, sample rate,
channel layout and bitrate. That is the technical description you would put in
a preservation record, and none of it is visible from the filename.

Then run a conformance check rather than a description:

    dp-run mediaconch video-sample.mp4

MediaConch answers a different question again: not "what is this" but "does it
meet a policy". Without a policy file it reports what it found; with one it
reports pass or fail against your rules.

--------------------------------------------------------------------------------
EXERCISE 3: THREE TOOLS DISAGREEING USEFULLY
--------------------------------------------------------------------------------

    dp-run exiftool  photo-with-exif.jpg
    dp-run tika-meta photo-with-exif.jpg
    dp-run mediainfo photo-with-exif.jpg

Three characterisation tools, one file, three different views. ExifTool knows
the most about camera metadata. Tika normalises across hundreds of formats.
MediaInfo is strongest on time-based media and will say least here.

None is the right answer. Which one you reach for depends on what you are
cataloguing, and knowing that is the skill.

--------------------------------------------------------------------------------
EXERCISE 4: DOCUMENT METADATA, AND WHERE IT HIDES
--------------------------------------------------------------------------------

    dp-run tika-meta document-with-metadata.odt
    dp-run odf-validator document-with-metadata.odt

The ODF file is a zip. Its metadata lives in a separate part inside it:

    unzip -p document-with-metadata.odt meta.xml | xmlstarlet fo

Author, creation date, a different modification date, a generator string and
keywords. The odf-validator run confirms the document is structurally sound as
ODF, which is a validation answer, not a characterisation one. Running both on
one file is the normal case, not an edge case.

--------------------------------------------------------------------------------
WHAT TO TAKE AWAY
--------------------------------------------------------------------------------

Characterisation is where preservation stops being about file formats and starts
being about what you are responsible for. A GPS coordinate, an author name and a
creation date are all facts your institution now holds, whether or not anyone
decided to collect them.

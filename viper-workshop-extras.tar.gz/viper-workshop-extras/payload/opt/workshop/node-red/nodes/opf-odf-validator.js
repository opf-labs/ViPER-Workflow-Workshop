module.exports = function (RED) {
    'use strict';
    const { execFile } = require('child_process');

    function OpfOdfValidator(config) {
        RED.nodes.createNode(this, config);
        const node = this;
        node.extended = config.extended === undefined ? "" : config.extended;
        node.on('input', function (msg, send, done) {
            send = send || function () { node.send.apply(node, arguments); };
            done = done || function (err) { if (err) { node.error(err, msg); } };

            // Accept either a path or an envelope from an upstream OPF node, so the
            // palette chains without a change node between every step.
            let target = msg.payload;
            if (Buffer.isBuffer(target)) {
                // Almost always Node-RED's own "file in" node upstream, which reads a
                // file's contents. Named diagnostically because the alternative is a
                // participant staring at a correct-looking flow that cannot work.
                node.status({ fill: 'red', shape: 'ring', text: 'got contents, need a path' });
                done('received file contents, not a path. The built-in "file in" node '
                   + 'reads bytes; put an OPF "files" node here instead, or an inject node '
                   + 'with the path as a string.');
                return;
            }
            if (target && typeof target === 'object') { target = target.file; }
            if (typeof target !== 'string' || target === '') {
                node.status({ fill: 'red', shape: 'ring', text: 'no path' });
                done('no file to work on. Set msg.payload to a path string, or put an OPF '
                   + '"files" node in front of this one.');
                return;
            }

            // msg.opts overrides the editor fields, one key per manifest option. Without
            // this a node can only ever do the same thing to every file, which breaks
            // any flow that needs a per-file output path or a format chosen at runtime.
            const overrides = (msg.opts && typeof msg.opts === 'object') ? msg.opts : {};
            const optionValue = function (name, configured) {
                return Object.prototype.hasOwnProperty.call(overrides, name)
                    ? overrides[name] : configured;
            };

            const args = ['odf-validator', target];
            const v_extended = optionValue('extended', node.extended);
            if (v_extended !== undefined && v_extended !== null && String(v_extended) !== '') {
                args.push('--opt', 'extended=' + v_extended);
            }
            node.status({ fill: 'blue', shape: 'dot', text: 'running' });

            execFile('/opt/workshop/bin/dp-run', args, { maxBuffer: 64 * 1024 * 1024 },
                function (error, stdout, stderr) {
                    let envelope;
                    try {
                        envelope = JSON.parse(stdout);
                    } catch (parseError) {
                        node.status({ fill: 'red', shape: 'ring', text: 'runner failed' });
                        done('dp-run produced no envelope: ' + (stderr || parseError.message));
                        return;
                    }
                    // Carry identification forward. Each node emits its own envelope,
                    // so without this the PUID that fido established is gone by the time
                    // a validator has run, and "route on PUID then validate" cannot be
                    // expressed as a chain. Only fills gaps: a validator that reports its
                    // own format keeps it.
                    const upstream = (msg.payload && typeof msg.payload === 'object')
                        ? msg.payload : null;
                    if (upstream) {
                        ['puid', 'format_name', 'format_version', 'mime'].forEach(function (key) {
                            if ((envelope[key] === null || envelope[key] === undefined)
                                && upstream[key]) {
                                envelope[key] = upstream[key];
                            }
                        });
                        // Provenance: which tools have touched this file, in order. This
                        // is what a PREMIS event list or a workflow report is built from.
                        envelope.chain = (upstream.chain || []).concat([{
                            tool: upstream.tool,
                            tool_version: upstream.tool_version,
                            stage: upstream.stage,
                            status: upstream.status
                        }]);
                    } else {
                        envelope.chain = [];
                    }

                    // One output, always an envelope. dp-run reports a tool failure as
                    // a status inside the envelope rather than a non-zero exit, so a
                    // second error channel here would only split what the policy layer
                    // has to switch on anyway.
                    msg.payload = envelope;
                    const bad = ['invalid', 'not_well_formed', 'failed', 'unidentified',
                                 'no_validator'].indexOf(envelope.status) >= 0;
                    node.status({
                        fill: bad ? 'yellow' : 'green',
                        shape: bad ? 'ring' : 'dot',
                        text: envelope.status + (envelope.puid ? ' ' + envelope.puid : '')
                    });
                    send(msg);
                    done();
                });
        });
    }

    RED.nodes.registerType('opf-odf-validator', OpfOdfValidator);
};

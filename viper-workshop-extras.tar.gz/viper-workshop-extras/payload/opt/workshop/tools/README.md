# Tool manifests

One YAML file per tool. **This directory is the single source of truth.** Both the
runner (`dp-run`) and the Node-RED palette are driven from it, and the palette is
*generated* from it at image build time, so a node and the tool it invokes cannot
describe different things.

Adding a tool means adding one file here and rebuilding. There is no second place to
edit.

## Schema

```yaml
id: jhove                     # manifest id, becomes "opf-jhove" in the palette
name: JHOVE                   # display name
vendor: Open Preservation Foundation
stage: validation             # identification | validation | characterization | action
homepage: https://...
description: >                # becomes the node's help text
  ...

version:                      # how to ask the tool its own version, for provenance
  command: [jhove, -h, TEXT]
  pattern: 'Rel\. ([0-9.]+)'  # first capture group is the version

node:                         # drives the generated palette node
  label: JHOVE
  colour: "#b8e0b8"
  icon: font-awesome/fa-check-circle
  options:                    # each becomes a field in the node's edit dialog
    - name: module
      label: Module
      type: select            # select | text | bool
      default: ""
      hint: Leave blank to let JHOVE pick
      choices: ["", PDF-hul, TIFF-hul]

invoke:
  command: jhove
  args_when:                  # appended only if that option has a value
    module: ["-m", "{module}"]
  args: ["-h", "JSON", "{file}"]
  parse: json                 # json | xml | csv | tsv | raw
  columns: [...]              # csv/tsv only: names for the columns
  timeout: 300                # seconds, default 300

extract:                      # dotted paths into the parsed output -> envelope fields
  status: jhove.repInfo.0.status
  format_name: jhove.repInfo.0.format
  errors: jhove.repInfo.0.messages
  properties: jhove.repInfo.0.properties

status_map:                   # the tool's own wording -> the closed vocabulary
  "Well-Formed and valid": valid
  "Not well-formed": not_well_formed

status_rules:                 # used when there is nothing to map
  on_success: valid
  on_failure: invalid

default_status: no_validator  # last resort
```

### Paths

Dotted, with a numeric segment indexing a list: `jhove.repInfo.0.status`. An empty path
means the whole document. Deliberately not JSONPath: the manifests only ever reach a
known field, and a reader should not need a reference manual.

### Status resolution order

1. `status_map`, matched against whatever `extract.status` found
2. `status_rules.on_success` / `on_failure`, on the process exit code
3. `default_status`
4. the stage's own default

The result is checked against the stage vocabulary, and a value outside it becomes a
warning in the envelope rather than a silent pass.

## Closed status vocabularies

| Stage | Values |
|-------|--------|
| identification | `identified` `unidentified` `multiple_matches` |
| validation | `valid` `invalid` `not_well_formed` `no_validator` |
| characterization | `characterized` `partial` `failed` |
| action | `completed` `failed` |

Validation keeps three distinct failures on purpose. "Well-formed but not valid" is not
the same problem as "not well-formed", and a policy may route them differently.

## Verified invocations

Every one of these was checked against the tools in this image on 2026-09-12, not taken
from upstream documentation.

| Tool | Structured output | Note |
|------|-------------------|------|
| fido | `-matchprintf` | Tailored TSV beats parsing the default nine-column CSV |
| DROID | `-Nr` | CSV to stdout. The only mode that avoids creating a profile |
| Tika | `-j` | **Not** `--json --metadata`; the long forms do not combine and fall back to text |
| JHOVE | `-h JSON` | JSON OutputHandler 1.4, new enough to rely on |
| veraPDF | `--format json` | |
| jpylyzer | none | **XML only.** `--format` selects what to validate against, not how to print |
| MediaConch | `--Format=json` | |
| ODF Validator | `-o JSON` | |
| MediaInfo | `--Output=JSON` | |
| ExifTool | `-json -a -G1` | |

## Timings worth knowing

`droid` takes about **10.8 seconds** on a single file against `fido`'s **0.27 seconds**,
almost all of it JVM start and signature loading. Both return the same PUID. That is why
the workshop routes on fido and uses DROID for exploration, and it is a fair thing to
show a room rather than assert.

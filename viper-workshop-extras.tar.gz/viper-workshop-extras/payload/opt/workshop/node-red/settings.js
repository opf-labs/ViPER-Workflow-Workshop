/**
 * Node-RED settings for the iPRES 2026 Digital Preservation Lifecycle workshop.
 *
 * Seeded into /config/.node-red on first start by svc-nodered. A participant who edits
 * this file keeps their edit, because the service only copies what is absent.
 *
 * No adminAuth. The editor listens on 127.0.0.1 inside a single participant's own
 * container and is reached only from that container's desktop, so a login here would
 * add a password to remember and protect nothing.
 */
module.exports = {
    uiPort: 1880,
    uiHost: "127.0.0.1",

    flowFile: "flows.json",
    // Readable in git and in a text editor, because participants take these home and
    // an LLM has to be able to read one back.
    flowFilePretty: true,

    userDir: "/config/.node-red",

    // The OPF palette is generated from /opt/workshop/tools at build time and lives
    // outside the volume, so it survives a participant clearing their user directory
    // and cannot drift from the manifests it was generated from.
    nodesDir: "/opt/workshop/node-red/nodes",

    logging: {
        console: { level: "info", metrics: false, audit: false }
    },

    exportGlobalContextKeys: false,

    functionGlobalContext: {
        // Paths a function node can reach without hardcoding them.
        workshop: "/opt/workshop",
        dpBin: "/opt/workshop/bin",
        corpus: "/config/test-corpus",
        shared: "/config/shared"
    },

    editorTheme: {
        page: { title: "ViPER Workflows" },
        header: { title: "ViPER Workflows" },
        palette: { editable: true },
        projects: { enabled: false },
        tours: false
    }
};
